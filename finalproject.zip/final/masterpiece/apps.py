from django.apps import AppConfig


class MasterpieceConfig(AppConfig):
    name = 'masterpiece'
