from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.models import User
from masterpiece.models import Quiz, Player ,Room
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.utils.safestring import mark_safe
import json

def index(request):
    honor_list = Player.objects.order_by('point')[::-1][0:3]
    context = {
        'no1': honor_list[0],
        'no2': honor_list[1],
        'no3': honor_list[2],
    }
    if request.method=='POST':
        data1 = request.POST['account_field']
        data2 = request.POST['password_field']
        query_set = Player.objects.filter(account=data1)
        
        if len(query_set)==0 or data2!=query_set[0].password:
            context.update({'alert': "wrong password"})
            context['flag'] = True  
            return render(request, 'masterpiece/index.html', context)
        HP = redirect('room/')
        HP.set_cookie('account', data1)
        return HP

    return render(request, 'masterpiece/index.html', context)

def room(request):
    return render(request, 'masterpiece/room.html', {})

def create(request):
    return render(request, 'masterpiece/create.html', {})

def search(request):
    return render(request, 'masterpiece/search.html', {})

def play(request, room_name):
    HP = render(request, 'masterpiece/play.html', {
        'room_name_json': mark_safe(json.dumps(room_name))
    })
    HP.set_cookie('roomid', room_name)
    HP.set_cookie('pdic', {'1': 0, '2': 0, '3': 0, '4': 0})
    exist = Room.objects.filter(id = room_name)

    if len(exist) == 0:
        r = Room(id=room_name, usera=request.COOKIES['account'], userb="", userc="", userd="")
        r.save()
        
        HP.set_cookie('order', 1)
        
    else:
        r = Room.objects.get(id = room_name)
        if r.usera == "":
            r.usera = request.COOKIES['account']
            r.save()
            HP.set_cookie('order', 1)
        elif r.userb == "":
            r.userb = request.COOKIES['account']
            r.save()
            HP.set_cookie('order', 2)
        elif r.userc == "":
            r.userc = request.COOKIES['account']
            r.save()
            HP.set_cookie('order', 3)
        else:
            r.userd = request.COOKIES['account']
            r.save()
            HP.set_cookie('order', 4)

    return HP
