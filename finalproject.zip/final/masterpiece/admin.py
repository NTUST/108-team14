from django.contrib import admin
from masterpiece.models import Quiz, Player
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User

@admin.register(Quiz)
class QuizAdmin(admin.ModelAdmin):
    list_display = ('id', 'category', 'answer')

@admin.register(Player)
class PlayerAdmin(admin.ModelAdmin):
    list_display = ('account', 'password', 'point')

# class MoreInline(admin.StackedInline):
#     model = More
#     can_delete = False
#     fk_name = 'user'

# class ExUserAdmin(admin.ModelAdmin):
#     list_display = ('username', 'password')
#     inlines = (MoreInline, )

#     def get_inline_instances(self, request, obj=None):
#         if not obj:
#             return list()
#         return super(ExUserAdmin, self).get_inline_instances(request, obj)

# admin.site.unregister(User)
# admin.site.register(User, ExUserAdmin)
