from asgiref.sync import async_to_sync
from channels.generic.websocket import WebsocketConsumer
from masterpiece.models import Quiz, Room
import json
import random

class ChatConsumer(WebsocketConsumer):
    qid = 0

    def connect(self):
        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = 'chat_%s' % self.room_name

        # Join room group
        async_to_sync(self.channel_layer.group_add)(
            self.room_group_name,
            self.channel_name
        )

        self.accept()

    def disconnect(self, close_code):
        # Leave room group
        async_to_sync(self.channel_layer.group_discard)(
            self.room_group_name,
            self.channel_name
        )

    # Receive message from WebSocket
    def receive(self, text_data):
        text_data_json = json.loads(text_data)
        if 'message' in text_data_json.keys():
            message = text_data_json['message']
        if 'chatmsg' in text_data_json.keys():
            chatmsg = text_data_json['chatmsg']
        if 'dx' in text_data_json.keys():
            dx = text_data_json['dx']
        if 'dy' in text_data_json.keys():
            dy = text_data_json['dy']
        if 'mx' in text_data_json.keys():
            mx = text_data_json['mx']
        if 'my' in text_data_json.keys():
            my = text_data_json['my']
        if 'ux' in text_data_json.keys():
            ux = text_data_json['ux']
        if 'uy' in text_data_json.keys():
            uy = text_data_json['uy']
        if 'roomid' in text_data_json.keys():
            roomid = text_data_json['roomid']
        if 'addpoint' in text_data_json.keys():
            addpoint = text_data_json['addpoint']
        if 'start' in text_data_json.keys():
            flag = True
        if 'correct' in text_data_json.keys():
            flag = True
        if 'timeup' in text_data_json.keys():
            flag = True
        if 'loaduser' in text_data_json.keys():
            lu = True


        if 'addpoint' in locals().keys():
            async_to_sync(self.channel_layer.group_send)(
                self.room_group_name,
                {
                    'type': 'onpoint',
                    'addpoint': addpoint
                }
            )
        if 'lu' in locals().keys():
            r = Room.objects.get(id=roomid)
            usera = r.usera
            userb = r.userb
            userc = r.userc
            userd = r.userd
            async_to_sync(self.channel_layer.group_send)(
                self.room_group_name,
                {
                    'type': 'onuser',
                    'users': [usera, userb, userc, userd]
                }
            )
            lu = False
        if 'flag' in locals().keys():
            qid = random.randint(1, 10)
            async_to_sync(self.channel_layer.group_send)(
                self.room_group_name,
                {
                    'type': 'onquiz',
                    'qnum': qid
                }
            )
            flag = False
        if 'message' in locals().keys():
            async_to_sync(self.channel_layer.group_send)(
                self.room_group_name,
                {
                    'type': 'chat_message',
                    'message': message,
                }
            )
        if 'chatmsg' in locals().keys():
            async_to_sync(self.channel_layer.group_send)(
                self.room_group_name,
                {
                    'type': 'chat_chatmsg',
                    'chatmsg': chatmsg,
                }
            )
        if 'dx' in locals().keys():
            async_to_sync(self.channel_layer.group_send)(
                self.room_group_name,
                {
                    'type': 'pointdxy',
                    'dxy': [dx, dy]
                }
            )
        if 'mx' in locals().keys():
            async_to_sync(self.channel_layer.group_send)(
                self.room_group_name,
                {
                    'type': 'pointmxy',
                    'mxy': [mx, my]
                }
            )
        if 'ux' in locals().keys():
            async_to_sync(self.channel_layer.group_send)(
                self.room_group_name,
                {
                    'type': 'pointuxy',
                    'uxy': [ux, uy]
                }
            )

        # Receive message from room group
    def onpoint(self, event):
        addpoint = event['addpoint']
        self.send(text_data=json.dumps({
            'addpoint': addpoint
        }))


    def onuser(self, event):
        usera = event['users'][0]
        userb = event['users'][1]
        userc = event['users'][2]
        userd = event['users'][3]

        self.send(text_data=json.dumps({
            'usera': usera,
            'userb': userb,
            'userc': userc,
            'userd': userd
        }))

    def onquiz(self, event):
        qnum = event['qnum']
        newquiz = Quiz.objects.get(id=qnum).answer

        self.send(text_data=json.dumps({
            'newquiz': newquiz
        }))

    def chat_message(self, event):
        message = event['message']

        self.send(text_data=json.dumps({
            'message': message,
        }))

    def chat_chatmsg(self, event):
        chatmsg = event['chatmsg']
        
        self.send(text_data=json.dumps({
            'chatmsg': chatmsg,
        }))

    def pointdxy(self, event):
        dx = event['dxy'][0]
        dy = event['dxy'][1]

        self.send(text_data=json.dumps({
            'dx': dx,
            'dy': dy
        }))
    
    def pointmxy(self, event):
        mx = event['mxy'][0]
        my = event['mxy'][1]

        self.send(text_data=json.dumps({
            'mx': mx,
            'my': my
        }))

    def pointuxy(self, event):
        ux = event['uxy'][0]
        uy = event['uxy'][1]

        self.send(text_data=json.dumps({
            'ux': ux,
            'uy': uy
        }))

