from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class Quiz(models.Model):
    
    id = models.IntegerField(primary_key=True, max_length=5)
    answer = models.CharField(max_length=20, help_text='The answer of the quiz')
    category = models.CharField(max_length=10)

    def __str__(self):
        return self.answer

class Player(models.Model):
    account = models.CharField(primary_key=True, max_length=20)
    password = models.CharField(max_length=20)
    point =  models.IntegerField(max_length=10, default=100)

    def __str__(self):
        return self.account

class Room(models.Model):
    id = models.CharField(primary_key=True, max_length=50)
    usera = models.CharField(max_length=50, default="waiting...")
    userb = models.CharField(max_length=50, default="waiting...")
    userc = models.CharField(max_length=50, default="waiting...")
    userd = models.CharField(max_length=50, default="waiting...")

    # @classmethod
    # def create(cls, id):
    #     room = cls(id=id, usera="", userb="", userc="", userd="")
    #     return room

    def __str__(self):
        return self.id

