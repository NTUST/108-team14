from django.urls import path
from django.conf.urls import url
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('room/', views.room, name='room'),
    path('create/', views.create, name='create'),
    path('search/', views.search, name='search'),
    url(r'^(?P<room_name>[^/]+)/$', views.play, name='play'),
]